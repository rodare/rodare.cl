
function toggleContent1() {
  // Get the DOM reference
  var contentId = document.getElementById("content1");
  // Toggle 
  contentId.style.display == "block" ? contentId.style.display = "none" : 
contentId.style.display = "block"; 
}


function toggleContent2() {
  // Get the DOM reference
  var contentId = document.getElementById("content2");
  // Toggle 
  contentId.style.display == "block" ? contentId.style.display = "none" : 
contentId.style.display = "block"; 
}

function toggleContent3() {
  // Get the DOM reference
  var contentId = document.getElementById("content3");
  // Toggle 
  contentId.style.display == "block" ? contentId.style.display = "none" : 
contentId.style.display = "block"; 
}

function toggleContent4() {
  // Get the DOM reference
  var contentId = document.getElementById("content4");
  // Toggle 
  contentId.style.display == "block" ? contentId.style.display = "none" : 
contentId.style.display = "block"; 
}

function toggleContent5() {
  // Get the DOM reference
  var contentId = document.getElementById("content5");
  // Toggle 
  contentId.style.display == "block" ? contentId.style.display = "none" : 
contentId.style.display = "block"; 
}

function toggleContent6() {
  // Get the DOM reference
  var contentId = document.getElementById("content6");
  // Toggle 
  contentId.style.display == "block" ? contentId.style.display = "none" : 
contentId.style.display = "block"; 
}